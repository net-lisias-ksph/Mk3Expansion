OVERVIEW
===================================================================================================================
This pack provides mew mk3 spaceplane parts in the form of engines, fuselage segments and aerodynamic accessories.

---This is a Work In Progress---
Everything is functional, but things like IVAs are not fully implemented, and part cost/mass/tech tree location is not finalized.

A note on the truncated fuselage entension: These are asymmetric parts, and due to the way KSP handles symmetry, at present these parts need to be manually mirrored on craft, the Editor symmetry doen't work.

INSTALLATION
===================================================================================================================
Place the GameData/Mk3Expansion folder in your Kerbal Space Program/GameData folder


LICENSE
===================================================================================================================
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License(http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode). 

ModuleManager - made by Sarbian & Ialdabaoth - http://forum.kerbalspaceprogram.com/threads/55219-Module-Manager-1-5-6-%28Jan-6%29

Interstellar Fuel Switch is distributed under its own licence (CC-NC-SA). Please find source code and more details at https://github.com/sswelm/KSPInterstellar/tree/master/FuelSwitch

Community Resource Pack, more details at http://forum.kerbalspaceprogram.com/threads/91998