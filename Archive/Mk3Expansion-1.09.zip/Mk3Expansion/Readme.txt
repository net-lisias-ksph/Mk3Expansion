OVERVIEW
===================================================================================================================
This pack provides mew mk3 spaceplane parts in the form of engines, fuselage segments and aerodynamic accessories.

---This is a Work In Progress Alpha Release---
Everything is functional, but things like IVAs are not fully implemented, and part cost/mass/tech tree location is not finalized.

A note on the OMS engines and truncated fuselage entensions: These are asymmetric parts, and due to the way KSP handles symmetry, at present these parts need to be manually mirrored on craft, the Editor symmetry doen't work.

INSTALLATION
===================================================================================================================
Place the GameData/Mk3Expansion folder in your Kerbal Space Program/GameData folder


LICENSE
===================================================================================================================
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License(http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode). 

This package redistributes the following plugin, Klockheed_Martian_Gimbal; its license information is included. 
